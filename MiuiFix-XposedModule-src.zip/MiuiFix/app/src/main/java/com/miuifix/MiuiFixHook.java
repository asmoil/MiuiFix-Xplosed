package com.miuifix;

import android.content.Intent;
import android.util.Log;

import de.robv.android.xposed.IXposedHookLoadPackage;
import de.robv.android.xposed.XC_MethodReplacement;
import de.robv.android.xposed.XposedBridge;
import de.robv.android.xposed.XposedHelpers;
import de.robv.android.xposed.callbacks.XC_LoadPackage;

public class MiuiFixHook implements IXposedHookLoadPackage {

    private static final String TAG = "MiuiFix";

    // Packages to hook
    private static final String[] TARGET_PACKAGES = {
        "com.xiaomi.account",
        "com.miui.home",
        "com.miui.notes",
        "com.miui.cloudservice",
        "com.xiaomi.market"
    };

    @Override
    public void handleLoadPackage(XC_LoadPackage.LoadPackageParam lpparam) throws Throwable {
        boolean isTarget = false;
        for (String pkg : TARGET_PACKAGES) {
            if (lpparam.packageName.equals(pkg)) {
                isTarget = true;
                break;
            }
        }
        if (!isTarget) return;

        Log.d(TAG, "Hooking package: " + lpparam.packageName);

        // Hook getMiuiFlags() — returns 0 instead of crashing
        try {
            XposedHelpers.findAndHookMethod(
                Intent.class,
                "getMiuiFlags",
                new XC_MethodReplacement() {
                    @Override
                    protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                        return 0;
                    }
                }
            );
            Log.d(TAG, "getMiuiFlags hooked OK for " + lpparam.packageName);
        } catch (Throwable t) {
            Log.w(TAG, "getMiuiFlags not found (already patched or not needed): " + t.getMessage());
        }

        // Hook setMiuiFlags() — silently ignore
        try {
            XposedHelpers.findAndHookMethod(
                Intent.class,
                "setMiuiFlags",
                int.class,
                new XC_MethodReplacement() {
                    @Override
                    protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                        return param.thisObject; // return Intent itself (fluent API)
                    }
                }
            );
            Log.d(TAG, "setMiuiFlags hooked OK for " + lpparam.packageName);
        } catch (Throwable t) {
            Log.w(TAG, "setMiuiFlags not found: " + t.getMessage());
        }

        // Hook addMiuiFlags() — silently ignore
        try {
            XposedHelpers.findAndHookMethod(
                Intent.class,
                "addMiuiFlags",
                int.class,
                new XC_MethodReplacement() {
                    @Override
                    protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                        return param.thisObject;
                    }
                }
            );
            Log.d(TAG, "addMiuiFlags hooked OK for " + lpparam.packageName);
        } catch (Throwable t) {
            Log.w(TAG, "addMiuiFlags not found: " + t.getMessage());
        }

        // Hook hasMiuiFlags() — return false
        try {
            XposedHelpers.findAndHookMethod(
                Intent.class,
                "hasMiuiFlags",
                int.class,
                new XC_MethodReplacement() {
                    @Override
                    protected Object replaceHookedMethod(MethodHookParam param) throws Throwable {
                        return false;
                    }
                }
            );
            Log.d(TAG, "hasMiuiFlags hooked OK for " + lpparam.packageName);
        } catch (Throwable t) {
            Log.w(TAG, "hasMiuiFlags not found: " + t.getMessage());
        }
    }
}
